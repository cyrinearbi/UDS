<?php
/**
 * Created by PhpStorm.
 * User: Cyrine
 * Date: 15/08/2017
 * Time: 2:07 PM
 */
namespace App;
use Illuminate\Database\Eloquent\Model;

class Order extends Model
{
    protected $fillable = ['total_price', 'date','user_id','supplier_id'];



    public function users()
    {
        return $this->hasMany('App\User');
    }


    public function suppliers()
    {
        return $this->hasMany('App\Supplier');
    }

    public function products()
    {
        return $this->belongsToMany('App\Models\Product', 'order_Product');
    }
}