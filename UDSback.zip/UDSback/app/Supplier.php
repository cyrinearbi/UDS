<?php
/**
 * Created by PhpStorm.
 * User: Cyrine
 * Date: 15/08/2017
 * Time: 2:20 PM
 */
namespace App;
use Illuminate\Database\Eloquent\Model;

class Supplier extends Model
{
    protected $fillable = ['name', 'email', 'phone', 'address'];





    public function orders()
    {
        return $this->belongsTo('App\Order');
    }
}