<?php

/**
 * Created by PhpStorm.
 * User: Cyrine
 * Date: 15/08/2017
 * Time: 2:05 PM
 */
namespace App;
use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    protected $fillable = ['name', 'price'];





    public function ingredients()
    {
        return $this->hasMany('App\Ingredient');
    }


    public function orders()
    {
        return $this->belongsToMany('App\Models\Order');
    }
}