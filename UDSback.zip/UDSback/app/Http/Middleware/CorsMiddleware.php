<?php
/**
 * Created by PhpStorm.
 * User: Cyrine
 * Date: 15/08/2017
 * Time: 2:56 PM
 */
 namespace App\Http\Middleware;
class CorsMiddleware {
    public function handleOld($request, \Closure $next)
    {
        $response = $next($request);
        $response->header('Access-Control-Allow-Methods', 'HEAD, GET, POST, PUT, PATCH, DELETE');
        $response->header('Access-Control-Allow-Headers', $request->header('Access-Control-Request-Headers'));
        $response->header('Access-Control-Allow-Origin', 'Content-Type');
        $response->header('Access-Control-Allow-Origin', '*');
        return $response;
    }

    public function handle($request, \Closure $next)
    {
        return $next($request)
            ->header('Access-Control-Allow-Headers', $request->header('Access-Control-Request-Headers'))
            ->header('Access-Control-Allow-Origin', 'Content-Type')
            ->header('Access-Control-Allow-Origin', '*')
            ->header('Access-Control-Allow-Methods', 'PUT, POST, DELETE, GET, HEAD, PATCH')
            ->header('Access-Control-Allow-Headers', 'Accept, Content-Type,X-CSRF-TOKEN')
            ->header('Access-Control-Allow-Credentials', 'true');
    }
}