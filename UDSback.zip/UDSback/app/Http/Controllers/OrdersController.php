<?php
/**
 * Created by PhpStorm.
 * User: Cyrine
 * Date: 15/08/2017
 * Time: 3:05 PM
 */



namespace App\Http\Controllers;

use App\Order;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class OrdersController extends Controller{
//create new Order
    public function createOrder(Request $request){

        $post = Order::create($request->all());

        return response()->json($post,201);

    }


    //updates Order
    public function updateOrder(Request $request, $id){
        $post  = Order::find($id);
        $post->total_pricename = $request->input('total_pricename');
        $post->date = $request->input('date');
        $post->user_id = $request->input('user_id');
        $post->supplier_id = $request->input('supplier_id');
        $post->save();


        return response()->json($post,200);
    }
//view Order
    public function viewOrder($id){
        $post  = Order::find($id);


        return response()->json($post,200);
    }
//delete Order
    public function deleteOrder($id){
        $post  = Order::find($id);
        $post->delete();

        return response()->json('Removed successfully.',204);
    }
//list Order
    public function index(){

        $post  = Order::all();

        return response()->json($post,200);

    }
}
?>