<?php
/**
 * Created by PhpStorm.
 * User: Cyrine
 * Date: 15/08/2017
 * Time: 2:49 PM
 */


namespace App\Http\Controllers;

use App\User;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Hashing\BcryptHasher;

class UsersController extends Controller{
//create new post
    public function add(Request $request){


        $user = User::create($request->all());



        return response()->json($user,201);

    }

    //updates post
    public function edit(Request $request, $id){
        $post  = User::find($id);
        $post->update($request->all());

        return response()->json($post,200);
    }
//view post
    public function view($id){
        $post  = User::find($id);


        return response()->json($post,200);
    }
//delete post
    public function delete($id){
        $post  = User::find($id);
        $post->delete();

        return response()->json('Removed successfully.',204);
    }
//list post
    public function index(){

        $post  = User::all();

        return response()->json($post,200);

    }
}
?>


