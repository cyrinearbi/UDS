<?php
/**
 * Created by PhpStorm.
 * User: Cyrine
 * Date: 15/08/2017
 * Time: 3:35 PM
 */
namespace App\Http\Controllers;

use App\Product;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class ProductsController extends Controller{
//create new Product
    public function createProduct(Request $request){

        $post = Product::create($request->all());

        return response()->json($post,201);

    }


    //updates Product
    public function updateProduct(Request $request, $id){
        $post  = Product::find($id);
        $post->name = $request->input('name');
        $post->price = $request->input('price');

        $post->save();

        return response()->json($post,200);
    }
//view Product
    public function viewProduct($id){
        $post  = Product::find($id);
        

        return response()->json($post,200);
    }
//delete Product
    public function deleteProduct($id){
        $post  = Product::find($id);
        $post->delete();

        return response()->json('Removed successfully.',204);
    }
//list Product
    public function index(){

        $post  = Product::all();

        return response()->json($post,200);

    }
}
?>