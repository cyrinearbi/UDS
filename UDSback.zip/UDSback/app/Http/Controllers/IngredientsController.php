<?php
/**
 * Created by PhpStorm.
 * User: Cyrine
 * Date: 15/08/2017
 * Time: 4:01 PM
 */

namespace App\Http\Controllers;

use App\Ingredient;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class IngredientsController extends Controller{

//create new Ingredient
    public function createIngredient(Request $request){

        $post = Ingredient::create($request->all());

        return response()->json($post,201);

    }




    //updates Ingredient
    public function updateIngredient(Request $request, $id){
        $post  = Ingredient::find($id);
        $post->name = $request->input('name');
        $post->note = $request->input('note');
        $post->products_id = $request->input('products_id');
        $post->save();

        return response()->json($post,200);
    }
//view Ingredient
    public function viewIngredient($id){
        $post  = Ingredient::find($id);
        return response()->json($post,200);

    }
//delete Ingredient
    public function deleteIngredient($id){
        $post  = Ingredient::find($id);
        $post->delete();

        return response()->json('Removed successfully.',200);
    }
//list Ingredient
    public function index(){

        $post  = Ingredient::all();

        return response()->json($post,200);

    }
}
?>