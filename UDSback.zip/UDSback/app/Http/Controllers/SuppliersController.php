<?php
/**
 * Created by PhpStorm.
 * User: Cyrine
 * Date: 15/08/2017
 * Time: 2:51 PM
 */

namespace App\Http\Controllers;

use App\Supplier;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class SuppliersController extends Controller{
//create new post
    public function createSupplier(Request $request){

        $post = Supplier::create($request->all());

        return response()->json($post,201);

    }


    //updates Supplier
    public function updateSupplier(Request $request, $id){
        $post  = Supplier::find($id);
        $post->name = $request->input('name');
        $post->email = $request->input('email');
        $post->phone = $request->input('phone');
        $post->address = $request->input('address');
        $post->save();

        return response()->json($post,200);
    }
//view Supplier
    public function viewSupplier($id){
        $post  = Supplier::find($id);


        return response()->json($post,200);
    }
//delete Supplier
    public function deleteSupplier($id){
        $post  = Supplier::find($id);
        $post->delete();

        return response()->json('Removed successfully.',204);
    }
//list Supplier
    public function index(){

        $post  = Supplier::all();

        return response()->json($post,200);

    }
}
?>