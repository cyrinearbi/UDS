<?php
/**
 * Created by PhpStorm.
 * User: Cyrine
 * Date: 15/08/2017
 * Time: 2:05 PM
 */
namespace App;
use Illuminate\Database\Eloquent\Model;

class Ingredient extends Model
{
    protected $fillable = ['name', 'note','products_id'];

    public function products()
    {
        return $this->belongsTo('App\Product');
    }
}