<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It is a breeze. Simply tell Lumen the URIs it should respond to
| and give it the Closure to call when that URI is requested.
|
*/


$app->get('/', function () use ($app) {
    return $app->version();
});
$app->get('/test', function () use ($app) {
    return 'ok';
});



$app->group(['prefix' => 'api/v1'], function($app)
{
    //Suppliers
    $app->group(['prefix' => 'Suppliers'], function($app)
    {
        $app->post('add','SuppliersController@createSupplier');
        $app->get('view/{id}','SuppliersController@viewSupplier');
        $app->put('edit/{id}','SuppliersController@updateSupplier');
        $app->delete('delete/{id}','SuppliersController@deleteSupplier');
        $app->get('index','SuppliersController@index');

    });
    //Ingredients
    $app->group(['prefix' => 'Ingredients'], function($app)
    {
        $app->post('add','IngredientsController@createIngredient');
        $app->get('view/{id}','IngredientsController@viewIngredient');
        $app->put('edit/{id}','IngredientsController@updateIngredient');
        $app->delete('delete/{id}','IngredientsController@deleteIngredient');
        $app->get('index','IngredientsController@index');

    });

    //Orders
    $app->group(['prefix' => 'Orders'], function($app)
    {
        $app->post('add','OrdersController@createOrder');
        $app->get('view/{id}','OrdersController@viewOrder');
        $app->put('edit/{id}','OrdersController@updateOrder');
        $app->delete('delete/{id}','OrdersController@deleteOrder');
        $app->get('index','OrdersController@index');

    });

    //Products
    $app->group(['prefix' => 'Products'], function($app)
    {
        $app->post('add','ProductsController@createProduct');
        $app->get('view/{id}','ProductsController@viewProduct');
        $app->put('edit/{id}','ProductsController@updateProduct');
        $app->delete('delete/{id}','ProductsController@deleteProduct');
        $app->get('index','ProductsController@index');
        $app->options('add','ProductsController@index');

    });


//users
    $app->group(['prefix' => 'users'], function($app)
    {
        $app->post('add','UsersController@add');
        $app->get('view/{id}','UsersController@view');
        $app->put('edit/{id}','UsersController@edit');

        $app->delete('delete/{id}','UsersController@delete');
        $app->get('index','UsersController@index');
    });

    $app->options('{all:.*}', ['middleware' => 'cors', function() {
        return response('');
    }]);
});