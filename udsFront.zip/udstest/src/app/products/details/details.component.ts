import { Component, OnInit } from '@angular/core';

import { Router, ActivatedRoute, Params } from '@angular/router';
import { Location } from '@angular/common';
import { ProductService } from '../../product.service';
import { SuperDetails } from '../../commun/superdetails.component';


@Component({
  selector: 'app-details',
  templateUrl: './details.component.html',
  styleUrls: ['./details.component.css']
})
export class DetailsComponent extends SuperDetails implements OnInit {

  constructor(service: ProductService, router: Router, route: ActivatedRoute) {
    super(service, router, route);
  }

  ngOnInit() {
    super.ngOnInit();
  }

}








