import { Component, OnInit, EventEmitter, Input, Output } from '@angular/core';
import { ProductService} from '../../product.service';
import { Router, ActivatedRoute } from '@angular/router';
import { SuperList } from '../../commun/superlist.component';

@Component({
  selector: 'app-list',
  templateUrl: '../../commun/list.component.html',
  styleUrls:  ['../../commun/list.component.css']
})
export class ListComponent extends SuperList implements OnInit {

  constructor(service:ProductService, router:Router, route: ActivatedRoute) { 
    super(service,router,route);
    this.cols = [ {field: 'name', header: 'Name'}, 
    {field: 'price', header: 'Price'}
    ];
  }

  ngOnInit() {
    this.update();
  }

}



