import { Component, OnInit, EventEmitter, Input, Output } from '@angular/core';
import { Supplierservice} from '../../suppliers.service';
import { Router, ActivatedRoute } from '@angular/router';
import { SuperList} from '../../commun/superlist.component';

@Component({
  selector: 'app-list',
  templateUrl: '../../commun/list.component.html',
  styleUrls:  ['../../commun/list.component.css']
})
export class ListComponent extends SuperList implements OnInit {

  constructor(service:Supplierservice, router:Router, route: ActivatedRoute) { 
    super(service,router,route);
    this.cols = [ {field: 'name', header: 'Name'}, 
    {field: 'email', header: 'Email'},
    {field: 'phone', header: 'Phone'},
    {field: 'address', header: 'Address'},
    ];
  }

  ngOnInit() {
    this.update();
  }

}



