import { Component, OnInit } from '@angular/core';

import { Router, ActivatedRoute, Params } from '@angular/router';
import { Location } from '@angular/common';
import { Supplierservice } from '../../suppliers.service';
import { SuperDetails } from '../../commun/superdetails.component';


@Component({
  selector: 'app-details',
  templateUrl: './details.component.html',
  styleUrls: ['./details.component.css']
})
export class DetailsComponent extends SuperDetails implements OnInit {

  constructor(service: Supplierservice, router: Router, route: ActivatedRoute) {
    super(service, router, route);
  }
  

  ngOnInit() {
    super.ngOnInit();
  }

}








