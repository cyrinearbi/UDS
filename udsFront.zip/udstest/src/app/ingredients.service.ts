import { Injectable } from '@angular/core';
import { SuperService} from './commun/superservice.service';
import { Http, Headers, Response } from '@angular/http';

@Injectable()
export class IngredientsService extends SuperService{

  constructor( http: Http) {
    super('Ingredients',http);
   }

}