import { Http, Headers, Response } from '@angular/http';



export class SuperService {

  protected baseUrl = 'http://192.168.25.227:8000/api/v1';
  protected collection = '';
  protected http:Http;

  constructor(collection:string, http: Http) { 
      this.http=http;
      this.collection=collection;
  }

  errorHandler = error => console.error(this.collection+'Service error', error);
  
  add(object) {
    return this.http.post(`${this.baseUrl}/${this.collection}/add`, object)
      .toPromise()
      .catch(this.errorHandler);
  }

  getAll():Promise<any> {
    return this.http.get(`${this.baseUrl}/${this.collection}/index`)
      .toPromise().then(response=>response.json())
      .catch(this.errorHandler);
  }

  getOne(id):Promise<any> {
    return this.http.get(`${this.baseUrl}/${this.collection}/view/${id}`)
      .toPromise().then(response=>response.json())
      .catch(this.errorHandler);
  }

  remove(id) {
    return this.http.delete(`${this.baseUrl}/${this.collection}/delete/${id}`)
      .toPromise().then(response=>response.json())
      .catch(this.errorHandler);
  }

  update(object) {
    return this.http.put(`${this.baseUrl}/${this.collection}/edit/${object.id}`, object)
      .toPromise().then(response=>response.json())
      .catch(this.errorHandler);
  }

  
}
