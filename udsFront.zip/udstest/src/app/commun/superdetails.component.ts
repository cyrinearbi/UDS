import { Router, ActivatedRoute, Params } from '@angular/router';
import { Location } from '@angular/common';

export class SuperDetails {


  selected = {};
  items = [
    {
      label: 'Cancel', icon: 'fa-close', command: () => {
        this.cancel();
      }
    }];

    

  constructor(protected service,protected router: Router,protected route: ActivatedRoute) {

  }

  ngOnInit() {
    this.route.params
      .switchMap((params: Params) => this.service.getOne(params['id']))
      .subscribe((object) => {
        this.selected = object;
      });
  }

  cancel() {
    this.router.navigate(['../..'], { relativeTo: this.route });
  }

  save() {
    if (this.selected['id']){
      this.service.update(this.selected)
      .then((data) => this.router.navigate(['../..'], { relativeTo: this.route }));

    }
    else{
      this.service.add(this.selected)
      .then((data) => this.router.navigate(['../..'], { relativeTo: this.route }));
    }
  }
}