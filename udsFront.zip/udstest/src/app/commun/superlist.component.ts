
import { Router, ActivatedRoute, Params } from '@angular/router';
import { Location } from '@angular/common';


export class SuperList {

 list:any[];
 cols=[];

  constructor(protected service,protected router: Router,protected route: ActivatedRoute) {

  }
  ngOnInit() {
    this.update();
  }

  update(){
    this.service.getAll().then(response=>{
      this.list=response;
    });
  }

  edit(id) {
    this.router.navigate(['details',id],{relativeTo: this.route});
  }

  remove(id) {
    this.service.remove(id)
      .then(() => this.update());    
  }


}