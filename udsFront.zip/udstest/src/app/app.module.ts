import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule,Http } from '@angular/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations'
import { AccordionModule,GrowlModule, DataListModule} from 'primeng/primeng';     //accordion and accordion tab
import { ToolbarModule,ButtonModule,SplitButtonModule} from 'primeng/primeng';
import {PanelModule} from 'primeng/primeng';



import { ProductService} from './product.service';
import { UserService} from './user.service';
import { IngredientsService} from './ingredients.service';

import { Supplierservice} from './suppliers.service';

import { SuppliersModule} from './suppliers/crud.module';
import { ProductsModule} from './products/crud.module';
import { UsersModule} from './users/crud.module';
import { IngredientsModule} from './ingredients/crud.module';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

@NgModule({
  declarations: [
    AppComponent

  ],
  imports: [
    BrowserModule,
    
    FormsModule,
    HttpModule,
    IngredientsModule,
    SuppliersModule,
    ProductsModule,
    UsersModule,
    AppRoutingModule,
    
    BrowserAnimationsModule,
    AccordionModule,GrowlModule,DataListModule,ToolbarModule,ButtonModule,SplitButtonModule,PanelModule
  ],
  providers: [ProductService,UserService,Supplierservice,IngredientsService],
  bootstrap: [AppComponent]
})
export class AppModule { }
