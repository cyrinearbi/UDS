import { Component, OnInit } from '@angular/core';

import { Router, ActivatedRoute, Params } from '@angular/router';
import { Location } from '@angular/common';
import { IngredientsService} from '../../ingredients.service';
import { ProductService } from '../../product.service';
import { SuperDetails } from '../../commun/superdetails.component';


@Component({
  selector: 'app-details',
  templateUrl: './details.component.html',
  styleUrls: ['./details.component.css']
})
export class DetailsComponent extends SuperDetails implements OnInit {

  products=[];

  constructor(service: IngredientsService, router: Router, route: ActivatedRoute,private productService:ProductService) {
    super(service, router, route);
  }
  

  ngOnInit() {
    this.route.params
    .switchMap((params: Params) => this.service.getOne(params['id']))
    .subscribe((object) => {
      this.selected = object;
      if (object['products_id']){
      this.productService.getOne(object['products_id']).then(response=>{
        this.selected['products_id']=response;
      
    });
  }   
      
    });
    this.updateProducts();
    }
  
  updateProducts() {
    this.productService.getAll().then(response => {
      this.products = response;
      console.log(this.products);
    });
  }

  filterProducts(event) {
    let query = event.query;
    this.productService.getAll().then(response => {
      this.products = response;
    });
  }
  save() {
    this.selected['products_id']=this.selected['products_id']['id'];
    super.save();
  }    
 
}








