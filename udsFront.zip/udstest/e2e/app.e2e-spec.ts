import { UDSFrontPage } from './app.po';

describe('udsfront App', () => {
  let page: UDSFrontPage;

  beforeEach(() => {
    page = new UDSFrontPage();
  });

  it('should display welcome message', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('Welcome to app!');
  });
});
